<?php
// config/config.php

define('DB_HOST', '192.168.219.110');
define('DB_NAME', 'pandakko');
define('DB_USER', 'pandakko');
define('DB_PASS', '!1qazsoftj');

define('BASE_URL', 'http://localhost:8000/kakao');
?>
