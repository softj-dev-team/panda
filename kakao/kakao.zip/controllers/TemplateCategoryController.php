<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/kakao/models/TemplateCategoryModel.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/kakao/models/SendTransaction.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/kakao/models/TemplateCategoryModel.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/kakao/core/Controller.php';
class TemplateCategoryController extends Controller
{
    private $templateCategory;
    private $sendTransaction;
    public function __construct()
    {
        $this->templateCategory = new TemplateCategoryModel();
        $this->sendTransaction = new SendTransaction();
    }

    public function getCategories()
    {
        try {
            $categories = $this->templateCategory->getAllCategories();
            $this->sendJsonResponse($categories);
        } catch (Exception $e) {
            error_log($e->getMessage());
            $this->sendJsonResponse(['error' => 'An error occurred']);
        }
    }
    public function sendMessage()
    {
        try {
            $name = $_POST['name'];
            $date = $_POST['date'];
            $system = $_POST['system'];
            $fdestine = $_POST['fdestine'];
            $fcallback = $_POST['fcallback'];

            $this->sendTransaction->saveMessage($name, $date, $system, $fdestine, $fcallback);
            echo "Message sent successfully!";
        } catch (Exception $e) {
            error_log($e->getMessage());
            echo "Failed to send message: " . $e->getMessage();
        }
    }

    public function sendJsonResponse($data)
    {
        header('Content-Type: application/json');
        echo json_encode($data);
    }
    public function showForm()
    {
        $this->view('template');
    }
}

// REST API 요청 처리
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller = new TemplateCategoryController();

    if (isset($_GET['action']) && $_GET['action'] === 'getCategories') {
        $controller->getCategories();
    } else {
        $controller->showForm();
    }
}else if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'sendMessage') {
    $controller = new TemplateCategoryController();
    $controller->sendMessage();
}
?>
