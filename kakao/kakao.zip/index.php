<?php
// index.php

require_once 'config/config.php';
require_once 'controllers/Send.php';
$controller= new Send();
$controller->index();
