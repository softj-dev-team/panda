<?php

require_once 'Database.php';

class TemplateCategoryModel
{
    private $conn;

    public function __construct()
    {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function getAllCategories()
    {
        $stmt = $this->conn->query('SELECT id, name, parent_id FROM template_category ORDER BY parent_id, name');
        return $stmt->fetchAll();
    }
}
?>
