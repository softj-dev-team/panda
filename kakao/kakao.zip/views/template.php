<?php require_once $_SERVER["DOCUMENT_ROOT"] . "/kakao/public/head.php"; ?>
<?php require_once $_SERVER["DOCUMENT_ROOT"] . "/pro_inc/check_login.php"; // 공통함수 인클루드?>
<body>
<!--header-->
<div><? require_once $_SERVER["DOCUMENT_ROOT"] ."/common/header.php"; ?></div>

<div class="wrap">
    <div class="container-kko">
        <div class="preview-section">
            <div id="preview">
                <div id="previewDate">2024년 07월 11일</div>
                <div id="previewChannelName">채널명</div>
                <div id="previewTemplate">
                    <div class="highlight-container">
                        <div class="highlight-header">
                            <span>알림톡 도착</span>
                            <div class="jss1382">kakako</div>
                        </div>
                        <div class="highlight-body">
                            <div id="previewHighlightTitle">123</div>
                            <div id="previewHighlightSubtitle">123</div>
                        </div>
                    </div>
                    <div class="previewFooter">오전 12:02</div>
                </div>
            </div>
            <p class="preview-note">미리보기는 실제 단말기와 차이가 있을 수 있습니다.</p>
        </div>
        <div class="form-section">
            <div class="fm-wrap w-100">
                <div class="fm-row flex">
                    <div class="fm-box w-100">
<!--                        <label for="f-sel" class="blind">발신프로필 선택 * 필수항목</label>-->
                        <select id="f-sel" class="fm-sel">
                            <option value="">발신프로필 선택 *</option>
                            <option value="">주식회사 리휴</option>
                            <option value="">주식회사 소프트제이</option>
                        </select>
                        <span class="fm-error-txt">항목을 선택해 주세요.</span><!-- 에러일 경우 class="active" 추가 -->
                    </div>
                    <button class="addChild"><i class="plusI"></i>발신프로필등록</button>
                </div>

            <div class="channel-link">
<!--                <button id="linkChannelBtn">채널 연동하기</button>-->
                <select id="category" name="category" class="fm-sel">
                    <option >기타 </option>
                </select>
            </div>
            <div class="template-type fm-row">
                <label>템플릿 유형</label>
                <div class="fm-box-row">
                    <input type="radio" class="fm-rad" id="basic" name="templateType" value="01" checked>
                    <label for="basic" class="fm-rad-i">기본형</label>

                    <input type="radio" class="fm-rad" id="highlight" name="templateType" value="02">
                    <label for="highlight" class="fm-rad-i">강조표기형</label>

                    <input type="radio" class="fm-rad" id="image" name="templateType" value="03">
                    <label for="image" class="fm-rad-i">이미지첨부형</label>

                    <input type="radio" class="fm-rad" id="list" name="templateType" value="04">
                    <label for="list" class="fm-rad-i">리스트형</label>
                </div>
            </div>
            <div class="template-content">
                <label for="templateName">템플릿 이름 (선택사항)</label>
                <input type="text" id="templateName">
                <div id="guide">
                    <div><label>내용: </label><input type="text" id="highlightTitle" ></div>
                </div>

            </div>
        </div>
        <div class="flex-c">
            <a href="#none" class="btn-t btn-c">템플릿 등록 완료</a>
        </div>
    </div>


<script src="/kakao/public/js/kakao.js"></script>
</body>
</html>
